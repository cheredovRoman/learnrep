﻿using System;

namespace lab6
{
    class Program
    {
        static void Main(string[] args)
        {
            //set
            setacc User = new setacc();
            obr obraz = new obr();
            place pl = new place();
            value money = new value();
            // init
            User.InitAccount("Sergey", "Ivanov", "Ivanov@gmail.com", "123123");
            obraz.Initobr("Altgtu","PI");
            User.university=obraz.Getuniversity();
            User.special = obraz.Getspecial();
            pl.Initplace("Russia","Barnaul");
            User.country = pl.Getcountry();
            User.city = pl.Getcity();
            money.Initvalue(100000,2000);
            User.max = money.Getmax();
            User.min = money.Getmin();
            //output
            Console.WriteLine("output:");
            User.OutputAccount();
            //delete
            Console.WriteLine("\nDelete: ");
            User.DeleteAccount();
            obraz.deleteobr();
            pl.Deleteplace();
            money.Deletevalue();
            User.OutputAccount();
            //input
            Console.WriteLine("Input: ");
            User.InputAccount();
            obraz.Inputobr();
            pl.Inputplace();
            money.Inputvalue();
            Console.WriteLine("Output NEW: ");
            User.OutputAccount();
        }
    }
}
