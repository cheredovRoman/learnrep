<template>
  <div class="about">
    <div class="hero is-info">
      <div class="hero-body has-text-centered">
        <h1 class="title">О приложении</h1>
      </div>
    </div>

    <section class="section">
      Это страница о создателях приложения.
    </section>
  </div>
</template>

<script>
export default {
  mounted() {
    document.title = 'О приложении | StudyNet'
  }
}
</script>