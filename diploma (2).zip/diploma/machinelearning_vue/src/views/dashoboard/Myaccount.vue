<template>
  <div class="about">
    <div class="hero is-info">
      <div class="hero-body has-text-centered">
        <h1 class="title">Мой аккаунт</h1>
      </div>
    </div>
    

    <section class="section">
      <div class="columns is-multiline">
        <div class="column is-12">
          <h2 class="subtitle is-size-3">Курсы которые вы проходите:</h2>
        </div>

        <div 
          class="column is-4"
          v-for="course in courses"
          v-bind:key="course.id"
        >
          <CourseItem :course="course" />
        </div>
      </div>

      <hr>
        
      <button @click="logout()" class="button is-danger">Выход из аккаунта</button>
    </section>
    <section class="section">
    <div>
      <h1>Настройки аккаунта</h1>
      <button class="button is-primary" @click="showForm = true">Изменить аккаунт</button>
      <form v-if="showForm" @submit.prevent="editAccount">
        <div class="field">
          <label class="label">Имя пользователя</label>
          <div class="control">
            <input type="text" class="input" v-model="username" />
          </div>
        </div>
        <div class="field">
          <label class="label">Пароль</label>
          <div class="control">
            <input type="password" class="input" v-model="password" />
          </div>
        </div>
        <div class="field">
          <div class="control">
            <button class="button is-primary">Сохранить изменения</button>
          </div>
        </div>
      </form>
    </div>
  </section>
  </div>
  <div class="notification is-warning" v-if="showNotification">
    <button class="delete" @click="closeNotification"></button>
    Настройки сохранены!
  </div>
</template>

<script>
import axios from 'axios'

import CourseItem from '@/components/CourseItem.vue'

export default {
    data() {
      return {
        courses: [],
        showForm: false,
        username: '',
        password: '',
      }
    },
    components: {
      CourseItem
    },
    
    mounted() {
      document.title = 'Мой аккаунт | StudyNet'
        axios
            .get('activities/get_active_courses/')
            .then(response => {
                console.log(response.data)

                this.courses = response.data
            })
    },
    methods: {
        async logout() {
            console.log('logout')
          
            await axios
              .post('token/logout/')
              .then(response => {
                console.log('Logged out')
              })
              .catch(error => {
                console.log(error)
              })

            axios.defaults.headers.common['Authorization'] = ""

            localStorage.removeItem('token')

            this.$store.commit('removeToken')

            this.$router.push('/')
        },
        editAccount() {
          console.log('изменения аккаунта')
          this.showForm = false
          this.showNotification = true;
        }
    }
}
</script>