<template>
    <div>
      <input
        type="text"
        v-model="searchTerm"
        placeholder="Поиск термина"
        class="search-input"
      />
      <ul class="term-list">
        <li
          v-for="term in filteredTerms"
          :key="term.id"
          class="term-item"
        >
          {{ term.name }}
        </li>
      </ul>
    </div>
  </template>
  
  <style scoped>
  .search-input {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 4px;
    width: 200px;
  }
  
  .term-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
  }
  
  .term-item {
    padding: 8px;
    border-bottom: 1px solid #ccc;
  }
  </style>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        searchTerm: '',
        terms: []
      };
    },
    computed: {
      filteredTerms() {
        return this.terms.filter(term =>
          term.name.toLowerCase().includes(this.searchTerm.toLowerCase())
        );
      }
    },
    watch: {
      searchTerm(newValue) {
        this.fetchTerms(newValue);
      }
    },
    methods: {
      async fetchTerms(searchTerm) {
        try {
          const response = await axios.get('/api/terms', {
            params: {
              search: searchTerm
            }
          });
          this.terms = response.data;
        } catch (error) {
          console.error(error);
        }
      }
    }
  };
  </script>