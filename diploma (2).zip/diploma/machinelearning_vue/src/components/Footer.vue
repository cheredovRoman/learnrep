<template>
    <footer class="footer">
        <p class="has-text-centered">Сделано в 2024 году</p>

    </footer>
</template>