<template>
    <nav class="navbar is-info" role="navigation" aria-label="main naviation" style="min-height: 5rem;">
        <div class="navbar-brand">
            <router-link class="navbar-item is-size-4" to="/">MachineLrn</router-link>
        </div>

        <div id="navbar-item" class="navbar-menu">
            <div class="navbar-start">
                <router-link to="/" class="navbar-item">Начальная страница</router-link>
                <router-link to="/about" class="navbar-item">О приложении</router-link>
                <router-link to="/courses" class="navbar-item">Курсы</router-link>
                <router-link to="/knowledge_base" class="navbar-item">База знаний</router-link>
            </div>

            <div class="navbar-end">
                <div class="navbar-item">
                    <div class="buttons">
                        <template v-if="$store.state.user.isAuthenticated">
                            <router-link to="/dashboard/create-course" class="button is-primary">Создать курс</router-link>
                            <router-link to="/dashboard/my-account" class="button is-info">Мой аккаунт</router-link>
                        </template>

                        <template v-else>
                            <router-link to="/sign-up" class="button is-primary"><strong>Зарегистрироваться</strong></router-link>
                            <router-link to="/log-in" class="button is-light">Войти</router-link>
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</template>