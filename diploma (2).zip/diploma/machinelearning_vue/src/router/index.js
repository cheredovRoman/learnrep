import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import AboutView from '../views/AboutView.vue'
import SignUp from '../views/SignUp.vue'
import LogIn from '../views/LogIn.vue'

import Myaccount from '../views/dashoboard/Myaccount.vue'
import KnowledgeBase from '../views/Knowledgebase.vue'

import Author from '../views/Author.vue'
import Courses from '../views/Courses.vue'
import Course from '../views/Course.vue'

import CreateCourse from '../views/dashoboard/CreateCourse.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: HomeView
  },
  {
    path: '/about',
    name: 'About',
    component: AboutView
  },
  {
    path: '/sign-up',
    name: 'SignUp',
    component: SignUp
  },
  {
    path: '/log-in',
    name: 'LogIn',
    component: LogIn
  },
  {
    path: '/courses',
    name: 'Courses',
    component: Courses
  },
  {
    path: '/courses/:slug',
    name: 'Course',
    component: Course
  },
  {
    path: '/authors/:id',
    name: 'Author',
    component: Author
  },
  {
    path: '/dashboard/my-account',
    name: 'Myaccount',
    component: Myaccount
  },
  {
    path: '/dashboard/create-course',
    name: 'CreateCourse',
    component: CreateCourse
  },
  {
    path: '/knowledge_base',
    name: 'KnowledgeBase',
    component: KnowledgeBase
  },

]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
