from django.contrib import admin

from .models import Activity

admin.site.register(Activity)