from django.contrib.auth.models import User

from rest_framework import serializers

from .models import Term

class TermSerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ('id', 'name', 'title')