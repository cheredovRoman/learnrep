from django.apps import AppConfig


class KnowledgebaseAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'knowledgebase_app'
